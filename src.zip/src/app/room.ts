export class Room {
    roomId!:number;
    roomType!:string; 
    totalRooms!:number;
    cost!:number;
    availableRooms!:number;
    roomRating!:string;
}