export class User {
    userId!:number;
    userName!:string;
    userEmail!:string;
    userPassword!:string;
}
// export class userinfo{
//     userId!:number;
//     userFirstName!:string;
//     userLastName!:string;
//     userEmail!:string;
//     userAge!:number;
//     userContactNumber!:number;
//     userGender!:string;
//     userCountry!:string;
//     userState!:string;
//     userAddress!:string;
// }
